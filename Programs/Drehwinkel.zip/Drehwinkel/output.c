#include "output.h"


static double elapsedTime = 0;
static double lastOutputTime = 0;

static int angle1 = 0;

int output()
{
    double t = getTime();
    if(t < lastOutputTime)
    {
        elapsedTime = t;
    }else elapsedTime += t - lastOutputTime;
    lastOutputTime = t;
    char s[10] = {0};


    if(elapsedTime >= MAX_TIME) 
    {
        //elapsedTime = 0;
        TimeError(elapsedTime);
        return -1;
    }
    if(elapsedTime >= MIN_TIME)
    {
        elapsedTime = 0;
        if(angle1 != (int)angle)
        {
            angle1 = angle;
            sprintf(s,"%.1f %.1f",angle,angularSpeed);
            //lcdPrintS(s);
        }
    }
    return 0;
}

void resetOutputTime()
{
    lastOutputTime = 0;
    elapsedTime = 0;
    //lcdPrintlnS("Time resetted");
}