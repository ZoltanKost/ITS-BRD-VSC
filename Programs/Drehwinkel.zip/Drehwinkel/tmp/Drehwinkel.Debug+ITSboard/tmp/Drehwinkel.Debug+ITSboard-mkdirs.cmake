# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION 3.5)

file(MAKE_DIRECTORY
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/1"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/tmp"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/src/Drehwinkel.Debug+ITSboard-stamp"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/src"
  "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/src/Drehwinkel.Debug+ITSboard-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/src/Drehwinkel.Debug+ITSboard-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "C:/githubUNI/GSP/ITS-BRD-VSC/Programs/Drehwinkel/tmp/Drehwinkel.Debug+ITSboard/src/Drehwinkel.Debug+ITSboard-stamp${cfgdir}") # cfgdir has leading slash
endif()
